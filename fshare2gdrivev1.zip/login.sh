#!/bin/bash
echo "Bắt đầu đăng nhập Fshare..."
# Lệnh đăng nhập sẽ được viết đầy đủ sau, đây là bản mô phỏng.
echo '{"session_id": "demo123", "token": "demo456"}' > login_result.json
